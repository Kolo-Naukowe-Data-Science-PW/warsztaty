/*
Ok, to naszą przygodę z D3 zaczniemy od użycia d3 do wyboru pewnych elementów ze strony internetowej
a potem użycia d3 do modyfikacji tych elementów

żeby przyjemnie nam się nam to robiło, na przykładową stronę wybrałam:
http://www.kwestiasmaku.com/desery/czekolada/czekolada_na_goraco/przepis.html

ok, to co będę chciała osiągnąć przez następne 5 minut, to po pierwsze zaznajomić Was
z selektorami z d3, a po drugie pokazać Wam, że d3 pozwala nie tylko
operować na elementach dokumentów, które sami będziemy tworzyć, ale też ogólnie na każdym 
dokumencie htmlowym, np. na naszym przepisie na gorącą czekoladę

ok, to co pierw musimy zrobić to załadować na tej stronie bibliotekę d3,
najłatwiej możemy to osiągnąć przez skopiowanie tekstu z pliku jsonowego z biblioteką d3
do konsoli JS,

otwieramy plik d3.min.js z naszego folderu warsztatowego, otwieramy go w sublime albo notatniku
bez różnicy i kopiujemy do schowka, potem przechodzimy do przeglądarki i wchodzimy prawym przyciskiem
w konsolę i przeklejamy tekst do niej i wywołujemy Enterem

jeśli udało nam się załadować naszą bibliotekę d3 powinniśmy dostać true w konsoli, ok
czyścimy konsolę
i upewniamy się jeszcze raz, że mamy dostęp do d3
wpisujemy d3. i widzimy, że rzeczywiście mamy dostęp do tego obiektu i do funkcji, które możemy
na nim wywołać

*/

/* pierwszą rzeczą jaką zrobimy to spróbujemy wybrać ten nagłówek Popularne 
  żeby to zrobić, klikamy prawym przyciskiem na ten nagłówek i klikamy zbadaj,
  Chrome przenosi nas wtedy do miejsca w kodzie w którym jest on zdefiniowany

  widzimy że jest to tag h2, z klasą block-title
  żeby go wybrać, użyjemy

*/

d3.select("h2")

/* to polecenie używa CSS selektorów, więc ma taką samą składnię, jak wcześniej omówiliśmy,
jeśli chcemy wybrać tag używamy po prostu jego nazwy 

zobaczmy co nam zwróciło to polecenie
widzimy, że jest to tablica, jednoelementowa, w której środku, jak najedziemy na ten kod
znajduje się nasz element, widzimy, że o niego nam chodziło, bo on właśnie podkreśla się na stronie

ten array jest po prostu arrayem, któremy d3 nadaje pewne wlasnosci (np. funkcje, ktorymi
potem mozemy na tym arrayo operować w d3 np. nadajac atrybuty obiektowi w nim się znajdującemu)

to co robi polecenie d3.select() to zwraca pierwszy napotkany element, który zostanie wybrany
przez ten selektor

a co jeśli chcemy wybrać wszystkie h2 i w ogóle jesteśmy ciekawi ile ich jest na stronie?

*/

d3.selectAll("h2")

/* widzimy że tym razem zwróciło na tablicę 3 elementową, z 3 nagłówkami h2 */

/* no to spróbujmy zmienić styl tych wszystkich nagłówków 
w tym celu spróbujemy zmienić kolor ich tekstu
*/

var naglowki = d3.selectAll("h2");
naglowki.style("color", "blue");
naglowki.style("font-size","30px");

/* widzimy, że rzeczywiście udało nam się zmienić  ten kolor i wielkość (patrzymy na stronę),
możemy też to potwierdzić patrząc na kod htmlowy, klikamy zbadaj na tym nagłówki i widzimy,
że to co tak naprawdę siedzi pod spodem, pod tą komendą d3 style(), to generacja w odpowiednim miejscu
wskazanego kodu, w naszym przypadku jest to dodanie tego stylu style=... do własności tego
nagłówka 
i to właśnie ta ważna cecha d3, pozwala nam wybierać elementy (jak i tworzyć o czym potem się przekonamy)
DOM-u i je modyfikować w szybszy i prostszy sposób a robi to po prostu generując pod spodem pewne
elementy kodu dokumentu


(dlaczego się zmienił styl, bo zmieniamy to w przeglądarce a pamiętamy że priorytety stylów zaczynały
się od przeglądarki chyba? w każdym razie ten styl pojawia się na samej górze stylów i powoduje
skreślenie pozostałych tego typu stylow w pozostałych style sheetach)

kolejna ważna rzecz jak już tu jesteśmy, zwróćmy uwagę na to co zwróciło nam to polecenie:
naglowki.style("color", "blue");

ponownie array z naszymi nagłówkami, tyle że już z tymi nagłówkami ze zmienionym stylem
to jest kolejna ważna sprawa w d3, kolejne instrukcje wywoływane na tym d3 selection zwracają
również to selection, to prowadzi do reguły łańcuchowej w d3
możemy pisać od razu po sobie te kolejne instrukcje
czyli u nas zamiast

var naglowki = d3.selectAll("h2");
naglowki.style("color", "blue");
naglowki.style("font-size","30px");


możemy napisać
*/

d3.selectAll("h2")
.style("color", "blue")
style("font-size","30px");

/* i działa to tak samo, a skraca o wiele zapis, będziemy widzieć tego typu napisy w d3
cały czas */

/* zadanie dla Was!!!  dla przypomnienia jeśli w CSS chcieliśmy wybrać element o konkretnej klasie, uzywaliśmy
tej klasy z .klasa, no więc zadanie dla Was
wybierzcie z tej strony ten napis CZEKOLADA NA GORĄCO i dodajcie do niego obramowanie solid i 3px
*/

/* to co robię to najeżdżam na ten nagłówek, klikam zbadaj, przenosi mnie do kodu, widzę, że
ten element ma 2 klasy przepis oraz page-header, spróbuję go wybrać za pomocą klasy przepis
pierw sprawdzę czy jest to jedyny element z tą klasą:

d3.select(".przepis")
widzę że tak, zatem zmieniam mu styl
d3.select(".przepis").style("border","solid 3px");
i rzeczywiście się udaje

widać tutaj, że wiedza z CSS się przydaje: i formułowanie selektorów i definiowanie stylów
wiemy co tak naprawdę robi d3, więc może trochę przydłużałam tym wstępem do tych 
wszystkich technologii, ale jak widać chyba to się przydaje

to by było na tyle edytowania tego co już jest stwórzmy coś!

*/