# Open it as R proj
if(!'pacman'%in% installed.packages()) install.packages("pacman")
require(pacman)

p_load(
  shinydashboard, tidyr, plyr,
  ggthemes, xts, scales, dplyr, shiny, extrafont, 
  extrafontdb, ggplot2, lubridate,
  ggthemes, magrittr, car,
  quantmod,  iterators, moments, RCurl,
  shinyjs, reshape2, DT, grid, png,
  RColorBrewer, htmltools, htmlwidgets, metricsgraphics,
  readr, readxl, knitr
)

options(
  shiny.trace = TRUE,
  shiny.reactlog = TRUE,
  digits.secs=3, 
  scipen = 999
)
rmarkdown::run('pw_presentation.Rmd',auto_reload = T) #if you change anything in run.Rmd the whole project will reload.

