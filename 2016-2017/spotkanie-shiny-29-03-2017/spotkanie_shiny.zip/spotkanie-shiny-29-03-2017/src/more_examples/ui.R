ui <- fluidPage(titlePanel("Getting Iframe"), 
                sidebarLayout(
                  sidebarPanel(
                    fluidRow(
                      column(6, selectInput("Member", label=h5("Choose a option"),choices=c('BCRA1','FITM2'))
                      ))),
                  mainPanel(fluidRow(
                    htmlOutput("iframe")
                  )
                  )
                ))
