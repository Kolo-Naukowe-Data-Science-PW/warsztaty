
server <- function(input, output) {
  output$iframe <- renderUI({
    input$Member
    github_site <-  "https://github.com/rstudio/shiny-examples"
    my_test <- tags$iframe(src=github_site, height=600, width=535)
    
  })
}

