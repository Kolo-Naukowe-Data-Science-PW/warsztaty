server=shinyServer(function(input, output) {
  
  output$main_plot <- renderPlot({
    
    hist(faithful$eruptions,
         probability = TRUE,
         breaks = as.numeric(input$n_breaks),
         xlab = "Duration (minutes)",
         main = "Geyser eruption duration")
    
    if (input$individual_obs) {
      rug(faithful$eruptions)
    }
    
    if (input$density) {
      dens <- density(faithful$eruptions,
                      adjust = input$bw_adjust)
      lines(dens, col = "blue")
    }
    
    
  })
  output$reactive_plot <- renderUI({
    if(input$real_time){
      
      list(
        #textOutput('text'),
        plotOutput('reactive_hist')
      )
    }
  })
    
  autoInvalidate <- reactiveTimer(1000)
  output$reactive_hist <- renderPlot({  
      autoInvalidate()
      hist(
        x = faithful$eruptions %>% {sample(., floor(length(.) / 2))},
        probability = TRUE,
        breaks = 10,
        xlab = "Duration (minutes)",
        main = "Geyser eruption duration"
      )
    })
  output$text <- renderText({
    autoInvalidate()
      Sys.time()
  })  
    
})