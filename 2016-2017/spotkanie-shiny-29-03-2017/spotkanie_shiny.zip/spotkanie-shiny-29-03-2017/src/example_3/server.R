

require(xts)
server <- shinyServer(function(input, output){
  
  get_new_data <- function(){
    data <- xts(rnorm(1),order.by =Sys.time() )
    
    return(data)
  }
  
  
  my_data <<- get_new_data()
  
  
  update_data <- function(){
    my_data <<- rbind(get_new_data(), my_data)
  }
  
  invalidator <- reactive({invalidateLater(input$time_interval)})
  output$dygraph <- renderDygraph({
  
    invalidator()
    
    dygraph(update_data(), main = "Sys.time")
    
  })
})


shinyApp(ui=ui,server=server)



# require(xts)
# server <- shinyServer(function(input, output){
#   
#   values <- reactiveValues()
#   values$b <- xts(rnorm(1), order.by = Sys.time())
#   
#   
#   values$b <- reactive({
#     invalidator
#     return(rbind(get_new_data(), values$b))
#     })
#   
#   get_new_data <- reactive({
#     data <- xts(rnorm(1, mean = input$mean, sd = input$sd), order.by = Sys.time())
# 
#     return(data)
#   })
#   # 
#   # 
#   # update_data <- reactive({
#   #   values$b <- rbind(get_new_data(), values$b)
#   #   values$b
#   # })
#   invalidator <- reactive({invalidateLater(input$time_interval)})
#   
#   output$dygraph <- renderDygraph({
#     
#     invalidator()
#     print(values$b)
#     
#     dygraph(values$b, main = "Sys.time")
#     
#   })
# })

