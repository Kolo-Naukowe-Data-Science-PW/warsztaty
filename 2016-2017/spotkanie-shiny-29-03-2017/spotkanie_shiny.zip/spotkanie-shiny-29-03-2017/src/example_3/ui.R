library(dygraphs)

ui=fluidPage(
  
  titlePanel("Real-time Randomness"),
  sidebarLayout(
    sidebarPanel(
      numericInput("time_interval","Time Interval (in ms)", 
                   value = 10000, min = 300, max = 400000, step = 12),
      numericInput('mean','Mean',value=0),
      numericInput('sd','Standard Deviation',value=1)
    ),
    mainPanel(
      dygraphOutput("dygraph")
    )
  )
)