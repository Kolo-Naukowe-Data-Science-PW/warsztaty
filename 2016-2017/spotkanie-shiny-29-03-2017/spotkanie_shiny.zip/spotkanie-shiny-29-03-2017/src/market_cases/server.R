server = function(input, output, session) {
  
  
  source('./src/market_cases/server/fin_dataset_rctv.R', local=T)
  source('./src/market_cases/server/trends_plot.R', local=T)# Plot
  source('./src/market_cases/server/observe_events.R', local=T)
  source('./src/market_cases/server/table.R', local=T)
  
}
