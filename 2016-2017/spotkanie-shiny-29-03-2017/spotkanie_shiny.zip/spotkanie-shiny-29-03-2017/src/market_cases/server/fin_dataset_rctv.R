fin_dataset_rctv <- reactive({
  input$change_dataset_btn
  fin_dataset <- readRDS(file='./src/market_cases/eurchf.RDS')
  isolate({
    if(input$case_select=='trump') fin_dataset <- readRDS(file='./src/market_cases/eurusd.RDS')
    if(input$case_select=='snb') fin_dataset <- readRDS(file='./src/market_cases/eurchf.RDS')
  })
  
  fin_dataset  
})
