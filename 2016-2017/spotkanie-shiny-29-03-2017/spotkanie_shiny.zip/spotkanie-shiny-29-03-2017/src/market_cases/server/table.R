output$table <- DT::renderDataTable({
  fin_dataset <- fin_dataset_rctv() %>%
    dplyr::filter(between(Index, input$date_time_2[1], input$date_time_2[2])) %>%
    dplyr::filter(complete.cases(.)) %>% 
    head(100)
  error_msg <- paste0('The dataset in this range is empty','. The data range for unfiltered set is between:\n',
                      min(fin_dataset_rctv()$Index,na.rm=T),' and\n',
                      max(fin_dataset_rctv()$Index,na.rm=T))
  shiny::validate(need(nrow(fin_dataset)>0, error_msg))

  fin_dataset
})