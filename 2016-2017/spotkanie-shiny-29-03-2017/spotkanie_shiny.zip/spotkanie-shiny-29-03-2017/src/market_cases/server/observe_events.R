observeEvent(fin_dataset_rctv(),{
  req(fin_dataset_rctv())
  req(input$date_time)
  updateSliderInput(
    session,
    inputId = 'date_time',
    label = 'Date time wider',
    min = min(fin_dataset_rctv()$Index, na.rm = T),
    max = max(fin_dataset_rctv()$Index, na.rm = T),
    value = c(
      quantile(fin_dataset_rctv()$Index, probs = 0.45, na.rm = T),
      quantile(fin_dataset_rctv()$Index, probs = 0.55, na.rm = T)
    ),
    step = 86400 / 3600 # One day is 86400 sec, so 86400 by 3600 is one minute for POSIX class variable.
  )
  
})


observeEvent({
  input$date_time

},{
  req(fin_dataset_rctv())
  req(input$date_time)
  new_date_time <- fin_dataset_rctv()$Index[between(fin_dataset_rctv()$Index, input$date_time[1],input$date_time[2])]
  req(new_date_time)
  min_ = min(new_date_time, na.rm = T)
  max_ = max(new_date_time, na.rm = T)
  
  # Here the most important part are req and step! If you don't set a step it will be default value which will not be very helpful in this case. 
  # Instead of req, you could use something less domain-specific, like 'if' block or tryCatch, in general I tried to make it less verbose.
    updateSliderInput(
      session, "date_time_2",
      'Date time narrow',
      value = c(
        quantile(new_date_time, probs = 0.45, na.rm = T), 
        quantile(new_date_time, probs = 0.55, na.rm = T)
      ),
      min = min_, 
      max = max_,
      step=(max_-min_)/200
    )

  
})