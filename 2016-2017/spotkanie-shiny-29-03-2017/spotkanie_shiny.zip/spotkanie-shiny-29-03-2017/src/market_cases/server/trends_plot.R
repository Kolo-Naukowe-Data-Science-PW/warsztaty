output$trends_plot <- renderPlot({
  
  req(fin_dataset_rctv())
  fin_dataset <- fin_dataset_rctv()
  input$render_plot_btn
  # It could have been written better but I had too little time :)
  
  if(input$spread_cb){
    isolate({
      to_ret <- fin_dataset %>% 
        dplyr::filter(between(Index, input$date_time_2[1], input$date_time_2[2])) %>% 
        mutate(spread = ask - bid) %>% 
        ggplot(aes(Index, y = spread)) + geom_step() + geom_point()+
        scale_x_datetime(labels = date_format())+
        #scale_x_datetime(breaks = date_breaks('1 hour'))+
        theme_economist() + 
        labs(y = 'Spread', x = '')
      return(to_ret) # In this case return is important
    })  
    
  }
  
  isolate({
    to_ret <- fin_dataset %>% 
      dplyr::filter(between(Index, input$date_time_2[1], input$date_time_2[2])) %>% 
      reshape2::melt(id.vars = 'Index') %>%
      ggplot(aes(Index, y = value, colour = variable)) + geom_step() + geom_point()+
      scale_x_datetime(labels = date_format())+
      labs(y = 'Exchange Rate', x = '', colour = 'Variable') + 
      #scale_x_datetime(breaks = date_breaks('1 hour'))+
      theme_economist()
    return(to_ret)
  })
  
  
})