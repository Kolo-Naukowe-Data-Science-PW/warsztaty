require(extrafont)
require(scales)
require(ggthemes)

### Color sets

mbank_colours_set_1<-c(
  rgb(43/255,79/255,104/255),
  rgb(156/255,181/255,188/255),
  rgb(0/255,136/255,202/255),
  rgb(118/255,121/255,122/255),
  rgb(249/255,176/255,0/255),
  rgb(0/255,21/255,32/255)
)




mbank_colours_set_2<-c(
  rgb(81/255,124/255,141/255),
  rgb(116/255,159/255,189/255),
  rgb(174/255,177/255,178/255),
  rgb(242/255,194/255,122/255),
  rgb(48/255,163/255,247/255),
  rgb(26/255,92/255,155/255),
  rgb(120/255,209/255,255/255),
  rgb(56/255,58/255,59/255),
  rgb(184/255,116/255,17/255)
)

mbank_colours_set_3<-c(
  rgb(193/255,189/255,151/255),
  rgb(148/255,138/255,84/255),
  rgb(141/255,124/255,141/255),
  rgb(128/255,65/255,91/255),
  rgb(73/255,24/255,104/255)
)

# 
# params <- ls(pattern = '^geom_', env = as.environment('package:ggplot2'))
# geoms <- gsub("geom_", "", params)
# lapply(geoms, update_geom_defaults, list(colour=pantone_7477))





scale_fill_gradient(low=mbank_colours_set_1[1],high=mbank_colours_set_1[3])
pantone_7477<-rgb(43/255,79/255,104/255)
cool_gray<-rgb(82/255,84/255,85/255)
process_blue_c<-rgb(0/255,136/255,202/255)
pantone_130<-rgb(249/255,176/255,0/255)




require(png)
require(grid)

theme_bw<-function(base_size=12, base_family = "Verdana") 
{
  theme_grey(base_size = base_size, base_family = base_family) %+replace% 
  theme(
    axis.text = element_text(size = rel(0.8)),
    axis.ticks = element_line(colour = "black"),
    axis.text.x = element_text(angle=90, hjust=1, vjust=1),
    legend.key = element_rect(colour = "grey80"),
    legend.position = "right",
    panel.background = element_rect(fill = "white", colour = NA),
    panel.border = element_rect(fill = NA, colour = "grey50"),
    panel.grid.major = element_line(colour = "grey90", size = 0.2),
    panel.grid.minor = element_line(colour = "grey98", size = 0.5),
    strip.background = element_rect(fill = "grey80", colour = "grey50", size = 0.2)
    )
}


require(ggthemes)

theme_economist<-function(base_size=12,base_family="Verdana"){
  ggthemes::theme_economist()%+replace%
    theme(axis.text.x=element_text(angle=90, hjust=1, vjust=1))


}

require(ggthemes)

theme_mbank <- function(base_size = 12,
                        base_family = "Verdana") {
  theme_bw() %+replace%
    theme(
      axis.text.x = element_text(
        angle = 90,
        hjust = 1,
        vjust = 1
      ),
      axis.text = element_text(colour = cool_gray),
      axis.title = element_text(colour = pantone_7477, face = 'bold'),
      legend.text = element_text(colour = process_blue_c, face = 'bold'),
      axis.line.x = element_line(),
      panel.border = element_blank(),
      plot.title = element_text(
        colour = process_blue_c,
        size = base_size * 2,
        face = 'bold',
        hjust = 0, vjust = 1
      ),
      plot.subtitle = element_text(
        colour = pantone_7477,
        face = 'bold',
        vjust = 1,
        hjust=0,
        size = base_size
      ), 
      # plot.caption = element_text(
      #   colour = pantone_7477,
      #   vjust = -1,
      #   hjust=-1,
      #   size = base_size*2/3
      # ), 
      
      
      plot.background = element_blank(),
      legend.key = element_rect(colour = rgb(43 / 255, 79 / 255, 104 /
                                               255)),
      #strip.background = element_rect(fill = 'white'),
      strip.background =  element_rect(colour = mbank_colours_set_2[5], fill = mbank_colours_set_2[5],
                                       size = 3, linetype = "dashed"),
      strip.text=element_text(colour='white'),
      #strip.text = element_text(colour = cool_gray),
      panel.grid.major.x = element_blank(),
      plot.margin = unit(c(1, 1, 0.5, 0.5), "lines")
    )
  
  
}




mbank_theme_function<-function(ggplot=spread_plot,
                               img = readPNG("images/mbank_logo.png",info=TRUE),
                               dimension_in_npc=0.05,
                               alpha_plot=0.7,
                               show_layout=FALSE){
  
  require(grid)
  
  dimension=attr(img,'info')$dim[1]/attr(img,'info')$dim[2]
  img <- matrix(rgb(img[,,1],img[,,2],img[,,3], alpha_plot), nrow=dim(img)[1])
  g <- rasterGrob(img, interpolate=TRUE) 
  
  heights = unit.c(unit(dimension_in_npc, "npc"), unit(1-dimension_in_npc, "npc"))
  widths = unit.c(unit(1-dimension_in_npc*dimension, "npc"),unit(dimension_in_npc*dimension, "npc"))
  lo = grid.layout(2, 2, widths = widths, heights = heights)
  # Show the layout
  if(show_layout) grid.show.layout(lo)
  
  
  # Position the elements within the viewports
  grid.newpage()
  pushViewport(viewport(layout = lo))
  
  # The plot
  pushViewport(viewport(layout.pos.row=1:2, layout.pos.col = 1:2))
  print(ggplot, newpage=FALSE)
  popViewport()
  
  # The logo
  pushViewport(viewport(layout.pos.row=1, layout.pos.col = 2,just='bottom'))
  print(grid.draw(g), newpage=FALSE)
  popViewport()
  
  
  
  
}


















