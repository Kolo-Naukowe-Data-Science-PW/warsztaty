
/* ---------------------- KOD 1 - skale R i Kolor */


//-------------- 1 


  var zmiennaR = "Population_2014";
  var skalaR = d3.scale.sqrt()
  skalaR.range([3, 30]);

  skalaR.domain( [ 0,  d3.max(jsonik, function(d){ return d[zmiennaR];}) ] ) 

  // jako atrybuty kolek
// .attr("r",function(d){return skalaR(d[zmiennaR]);})
//-------------- 2


  var zmiennaKolor = "Region"
  var skalaKolor = d3.scale.category10(); /* mamy też .category20/20b/20c */

  /* możemy sami ustalić kolory, podając własny range 
   	(+ zmieniając skalę na .ordinal dla porzadku, choć nie jest to konieczne)

  	var skalaKolor = d3.scale.ordinal();
  	skalaKolor.range(['#e41a1c','#377eb8','#4daf4a','#984ea3','#ff7f00','#ffff33','#a65628']);

	kolory można czerpać np. z:
	http://colorbrewer2.org/  (można kliknąć po prawej export i mieć gotowy array w JS <3 )
	https://color.adobe.com/pl/create/color-wheel/ (palety do wybierania 5 kolorów)

	*/


  var unikalneRegiony = d3.nest()
                        .key(function(d) { return d[zmiennaKolor]; })
                        .entries(jsonik)
                        .map(function(d){return d.key;})

  skalaKolor.domain(unikalneRegiony);


  // jako atrybuty kolek
       
      // .attr("fill", function(d){return skalaKolor(d[zmiennaKolor]);})

//-------------- 3

// sortujemy dane po Population

jsonik.sort(function(x, y){
   return d3.descending(x[zmiennaR], y[zmiennaR]);
})




/* ---------------------- KOD 2 - oś X */



//-------------- 1

  var xAxis = d3.svg.axis()
                    .scale(skalaX)
                    .orient("bottom")
                    //.outerTickSize(0)
                    //.innerTickSize(-height) 
                    //.tickPadding(10)
                    //.tickFormat(d3.format("3.f"))
                    //.tickValues([0.1, 1,5,10, 50, 100])
                    
                    


  var xAxisG = g.append("g")
                  .attr("class", "axis x") 
                  //.attr("transform", "translate(0," + height + ")")

  xAxisG.call(xAxis);


//-------------- 2 dodajemy do <style> </style>

   .axis path  {
        fill: none;
        stroke: black;
        stroke-width: 1.5px;
      }


//-------------- 3

  // tytul osi X
  xAxisG.append("text")
        .attr("text-anchor", "end")
        .attr("x", width)
        .attr("y", margin.bottom*(2/3))
        .text("PKB (PPP) per capita w tys. dolarów");




/* ---------------------- KOD 3 - siatka */


//-------------- 1 

		//odkomentować outer/inner TickSize

//-------------- 2 

	   // dodajemy do <head>

   <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet"> 


   	// dodajemy do <style> </style>

  .axis line{
	     stroke: black;
	     stroke-width: 1px;
	     stroke-opacity: 0.2;
	  	}


     .axis text {
        font-family: 'Raleway', sans-serif;
        font-size: 12px;
     }

  .tytuly {
        font-family: 'Raleway', sans-serif;
     }



/* ---------------------- KOD 4 - tooltipy */

//-------------- 1

var zmiennaEtykiety = "Country Name"

var tooltipki=d3.select("#chart").append("div").attr("id", "tooltip").style("opacity",0)

  kolka
  .on("mouseover", function(d){


      tooltipki.html( "<b>" + d[zmiennaEtykiety] +"</b>" + "<br/>"+
          d[zmiennaKolor] + "<br/>"
           )
      .style("left", (d3.event.pageX ) + "px") /* ustalamy pozycje elementu tam gdzie zostanie akcja podjeta */
      .style("top", (d3.event.pageY) + "px")
      .style("opacity",1);
    

      d3.select(this)
            .style("stroke-width", "3px");



      }

    )

//-------------- 2

/* do tooltipow */
  #tooltip { 
    position: fixed;  /* jest pozycjonowana pikselami ktore zostaly podane */  
    height: auto;
    width:  auto;       
    padding: 5px;       
    font: 10px sans-serif;  
    text-align: left;      
    background: white; /* tlo */
    border: 10px;    /* obramowanie */
    border-radius: 10px;    /* obramowanie zaokrąglone */ 
    box-shadow:  0px 0px 10px 3px rgba(0,0,0,0.57); 
    pointer-events: none;/*zeby nie reagował na najechanie na niego myszką, to co my robimy to tworzymy tooltipa i potem
    go ukrywamy lub nie, jest niewidoczny ale jest, wiec mozna na niego najechac myszka, jesli najedziemy na niego,
    to nie mamy dostepu do elementow pod nim, mozna by było po prostu tworzyc i usuwac go w .on */
      
  }






















































/* dodatkowe funkcjonalności */





/* ---------------------- KOD 5 - animacje Polska */



//-------------- 1


kolka.attr("class", function(d){

          if(d[zmiennaEtykiety] == "Polska"){
            return "kolkoPolska";
          } else {
            return "kolko";
          }


       })


var liniaPolska = g.append("line")
				   .attr("x1", d3.select(".kolkoPolska").attr("cx")) // !!! getter 
				   .attr("y1", d3.select(".kolkoPolska").attr("cy"))
				   .attr("x2", d3.select(".kolkoPolska").attr("cx")) // !!! getter 
                   .attr("y2", skalaY(7))
                   .style("stroke","black")
                   .style("stroke-dasharray",3)


var adnotacja = g.append("text")
                  .attr("class","adnotacja")
                  .attr("x", d3.select(".kolkoPolska").attr("cx")) 
                  .attr("text-anchor", "middle")
                  .attr("font-size", "14px")
                  .attr("y", skalaY(7)-10)
                  .text("Polska")
                  .style("cursor", "pointer") // wait :o




//-------------- 2 



var czyPolskaJestDuza = false;

adnotacja
	.on("click", function(){

		czyPolskaJestDuza  = !czyPolskaJestDuza;

		if(czyPolskaJestDuza){
			d3.select(".kolkoPolska")
			//.transition()
			//.delay(1000)
			//.duration(1000)
			.attr("r", 100)
		} else{

			d3.select(".kolkoPolska")
				//.transition()
				//.delay(1000)
				//.duration(1000)
				.attr("r", function(d){return skalaR(d[zmiennaR]);})


		}



	})

//-------------- 3 do <style>

.adnotacja {
        font-family: 'Raleway', sans-serif;
     }


//-------------- 4 odkomentowa transition duration delay



/* ---------------------- KOD 6 - ładne wyświetlanie wielkości populacji */


//-------------- 1 

var formatPopulacji = function(liczba, miejsca){

  if(liczba >= 1e+9){
    return (liczba/1e+9).toFixed(miejsca)+" mld";
  } else if ( liczba >= 1e+6){
    return (liczba/1e+6).toFixed(miejsca)+" mln";
  } else {
    return (liczba/1e+3).toFixed(miejsca)+" tys."
  }

//-------------- 2  w tooltip.html zmienić odpowiednią część na:

  "Populacja: " + "<b>" +formatPopulacji(d[zmiennaR],2)  +"</b>" + "<br/>"


  /* ---------------------- KOD 7 - legenda dla wielkości */

//-------------- 1 




kolka.attr("class", function(d){

          if(d[zmiennaEtykiety] == "Polska"){
            return "kolkoPolska"+ " " + d[zmiennaKolor].split(' ').join('_') ;
          } else {
            return "kolko"+ " " + d[zmiennaKolor].split(' ').join('_');
          }


       })


var legendaKolor = svg.append("g")
  	.attr("class", "legend kolor")
  	.attr("transform", "translate(" + (width + margin.left + 20 )  + "," + margin.top + ")") //ustalam pozycje x i y dla calej grupy
  	.selectAll("g")
  	.data(unikalneRegiony)
    .enter()
    .append("g")
    
  legendaKolor.append("rect")
              .attr("fill", function(d){ return skalaKolor(d);})
              .attr('stroke', "black")
              .attr("y", function(d,i){ return 35*i; })
              .attr("width", 10)
              .attr("height", 10)

  var tekst = legendaKolor.append("text")
  			  .attr("x", 20) // odsuwam od prostoków w prawo o 20px
              .attr("y", function(d,i){ return 35*i+10; }) // 10 to szerokosc kwadratum
              .attr("class", function(d){ return "legenda" + " " + d.split(' ').join('_'); } )
              .style("cursor", "pointer")
              .text(function(d){return d;})
			  .on("click", function(){

					var regionik = d3.select(this).attr("class").split(' ')[1];

					// wybieram kolka z g!!! nie z svg ktore nie sa klasy regionik
					g.selectAll("circle:not(."+ regionik+")")
											.transition()
											.duration(1500)
											.style("opacity", "0") // zamiast 0 1e-6 moze
											.style("pointer-events","none");

					
					g.selectAll("circle."+regionik)
						.transition()
						.duration(1500)
						.style("opacity", "1")
						.style("pointer-events","auto");


				})
			  .on("dblclick", function(){


			 		d3.selectAll("circle")
			 		.transition()
			 		.duration(100)
			 		.style("opacity", 1)
			 		.style("pointer-events","auto");

			  })


  /* ---------------------- KOD 8 - legenda dla wielkości */

//-------------- 1 


 var wielkosci = [1e+9,1e+8,1e+6];

  var legendaWielkosc = svg.append("g")
  .attr("class", "legend")
  .attr("transform", "translate(" + (width + margin.left + margin.right*(1/3))  + "," + (margin.top+unikalneRegiony.length*35+30) + ")")
	.selectAll("g")
  	.data(wielkosci)
    .enter()
    .append("g")
 

  legendaWielkosc.append("circle")
              .attr("fill", "none")
              .attr('stroke', "black")
              .style('stroke-dasharray', 2)
              .attr("r", function(d){return skalaR(d);})
              .attr("cy", function(d,i){ return i*2*skalaR(d3.max(wielkosci));})
              

  legendaWielkosc.append("text")
              .attr("y", function(d,i){ return i*2*skalaR(d3.max(wielkosci)); })
              .text(function(d){return formatPopulacji(d,0);})
              .attr("x", function(d){ return skalaR(d3.max(wielkosci))+10;})

//-------------- 2 w <style>

.legend{
        font-family: 'Raleway', sans-serif;
        font-size: 12px;
     }





 /* ---------------------- KOD 9 - strzałki */


var defs = svg.append("defs")

		defs.append("marker")
				.attr({
					"id":"arrow_poz",
					"viewBox":"0 -5 10 10",
					"refX":5,
					"refY":0,
					"markerWidth":4,
					"markerHeight":4,
					"orient":"0"
				})
				.append("path")
					.attr("d", "M0,-5L10,0L0,5")
					.attr("class","arrowHead")

		defs.append("marker")
				.attr({
					"id":"arrow_pion",
					"viewBox":"0 -5 10 10",
					"refX":5,
					"refY":0,
					"markerWidth":4,
					"markerHeight":4,
					"orient":"-90"
				})
				.append("path")
					.attr("d", "M0,-5L10,0L0,5")
					.attr("class","arrowHead")


svg.selectAll(".axis.x path")
.attr("marker-end","url(#arrow_poz)")

svg.selectAll(".axis.y path")
.attr("marker-start","url(#arrow_pion)")
